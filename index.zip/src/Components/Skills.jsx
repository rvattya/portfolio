import React from 'react'

const Skills = () => {
  return (
    <>
    <section id='skills' className='h-56'>
<h1>this is my skills section</h1>
    </section>
    </>
  )
}

export default Skills