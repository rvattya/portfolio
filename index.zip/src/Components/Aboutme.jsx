import React from 'react'

const Aboutme = () => {
  return (
    <>
    <section id='aboutme' className='h-56 '>
        <h1>this is about me </h1>

    </section>
    </>
  )
}

export default Aboutme