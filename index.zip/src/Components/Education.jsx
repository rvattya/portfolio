import React from 'react'

const Education = () => {
  return (
  <>
  <section id='education' className='h-56'>
    <h1>this is my education section</h1>
  </section>
  </>
  )
}

export default Education