import React from 'react'

const Contact = () => {
  return (
   <>

   <section id='contact' className='h-56 '> 
    <h1>about my contact</h1>
   </section>
   </>
  )
}

export default Contact