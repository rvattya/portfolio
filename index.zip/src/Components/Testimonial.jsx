import React from 'react'

const Testimonial = () => {
  return (
   <>
   <section id='testimonial' className='h-56'>
    <h1>this is testimonials</h1>
   </section>
   </>
  )
}

export default Testimonial