import React from 'react'

const Projects = () => {
  return (
   <>
   <section id='projects' className='h-56'>

    <h1>this is my all projects</h1>
   </section>
   </>
  )
}

export default Projects