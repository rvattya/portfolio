import React from 'react'

const Experience = () => {
  return (
   <>
   <div id='experience' className='h-56'>
    <h1>this is my experience</h1>
   </div>
   </>
  )
}

export default Experience