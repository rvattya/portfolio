import React from 'react'

const Resume = () => {
  return (
    <>
    <section id='resume' className='h-56'>
        <h1>this is my resume section</h1>
    </section>
    </>
  )
}

export default Resume